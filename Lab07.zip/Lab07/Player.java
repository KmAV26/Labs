
public interface Player {
	int[] makeMove(char[][] board);
	char getSymbol();
	String getName();
	}

