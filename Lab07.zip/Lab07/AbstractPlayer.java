
public abstract class AbstractPlayer {
	protected String name;
	protected char symbol;
	public AbstractPlayer(String name, char symbol) {
	this.name = name;
	this.symbol = symbol;
	}
	public String getName() {
	return name;
	}
	public char getSymbol() {
	return symbol;
	}
	public abstract int[] makeMove(char[][] board);

	}
	

	
