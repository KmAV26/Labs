
	public class HumanPlayer extends AbstractPlayer implements Player {
	public HumanPlayer(String name, char symbol) {
	super(name, symbol);
	}

	@Override
	public int[] makeMove(char[][] board) {
	return new int[0];
	}
	}