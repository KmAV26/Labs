
public class GameController {
	private GameLogic logic;
    private TicTacToeGUI gui;
   
   
    public GameController() {
        Player p1 = new HumanPlayer("Player X", 'X');
        Player p2 = new HumanPlayer("Player O", 'O');
        logic = new GameLogic(p1, p2);
        logic.startGame();
        gui = new TicTacToeGUI(this);
        gui.updateBoard(logic.getBoard());
        gui.showMessage(logic.getCurrentPlayer().getName() + "'s turn");
    }

    public void onCellClicked(int row, int col) {
        if (logic.makeMove(row, col)) {
            gui.updateBoard(logic.getBoard());

            if (logic.checkWin()) {
                gui.showWinner(logic.getCurrentPlayer().getName());
               
            } else if (logic.isDraw()) {
                gui.showDraw();
            } else {
                logic.switchPlayer();
                gui.showMessage(logic.getCurrentPlayer().getName() + "'s turn");
            }
        } else {
            gui.showMessage("Cell is already filled. Try again.");
        }
    }

    public void onResetClicked() {
        logic.resetGame();
        gui.clearBoard();
        gui.updateBoard(logic.getBoard());
        gui.showMessage(logic.getCurrentPlayer().getName() + "'s turn");
    }

    public static void main(String[] args) {
        new GameController();
    }
}


