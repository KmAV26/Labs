
public interface Employee {
	double calculateSalary();
	void displayDetails();
}
