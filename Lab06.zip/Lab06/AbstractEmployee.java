
abstract class AbstractEmployee {
	protected String name;
    protected JobType jobType;
    protected double base_salary;
   
    public AbstractEmployee(String name, JobType jobType, double base_salary) {
        if (base_salary < 0) {
            throw new IllegalArgumentException("Salary cannot be negative");
        }
        this.name = name;
        this.jobType = jobType;
        this.base_salary = base_salary;
    }
   
    public String getName() {
        return name;
    }
   
    public JobType getJobType() {
        return jobType;
    }
   
    public abstract void displayDetails();

	public double calculateSalary() {
		// TODO Auto-generated method stub
		return 0;
	}

	}
	

