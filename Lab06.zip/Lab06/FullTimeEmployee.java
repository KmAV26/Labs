
public class FullTimeEmployee extends AbstractEmployee implements Employee {
	private double bonus;
	   
    public FullTimeEmployee(String name, JobType jobType, double base_salary, double bonus) {
        super(name, jobType, base_salary);
        if (bonus < 0) {
            throw new IllegalArgumentException("Bonus cannot be negative");
        }
        this.bonus = bonus;
    }

    @Override
    public double calculateSalary() {
        return base_salary + bonus;
    }
   
    @Override
    public void displayDetails() {
        System.out.printf("Name: %s | Job Type: %s | Salary: $%.2f (Base: $%.2f, Bonus: $%.2f)%n",
                name, jobType, calculateSalary(), base_salary, bonus);
    }
}

