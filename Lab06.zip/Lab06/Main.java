
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static ArrayList<Employee> employees = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static void addFullTimeEmployee() {
        try {
            System.out.print("Enter full-time employee name: ");
            String name = scanner.nextLine();
           
            System.out.print("Enter base salary: ");
            double baseSalary = Double.parseDouble(scanner.nextLine());
            if (baseSalary < 0) {
                System.out.println("Warning: Negative salary entered. Setting to 0.");
                baseSalary = 0;
            }
           
            System.out.print("Enter bonus: ");
            double bonus = Double.parseDouble(scanner.nextLine());
            if (bonus < 0) {
                System.out.println("Warning: Negative bonus entered. Setting to 0.");
                bonus = 0;
            }
           
            employees.add(new FullTimeEmployee(name, JobType.FULL_TIME, baseSalary, bonus));
            System.out.println("Full-time employee added successfully!");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numbers for salary and bonus.");
        }
    }

    private static void addPartTimeEmployee() {
        try {
            System.out.print("Enter part-time employee name: ");
            String name = scanner.nextLine();
           
            System.out.print("Enter hourly rate: ");
            double hourlyRate = Double.parseDouble(scanner.nextLine());
            if (hourlyRate < 0) {
                System.out.println("Warning: Negative rate entered. Setting to 0.");
                hourlyRate = 0;
            }
           
            System.out.print("Enter hours worked: ");
            double hours = Double.parseDouble(scanner.nextLine());
            if (hours < 0) {
                System.out.println("Warning: Negative hours entered. Setting to 0.");
                hours = 0;
            }
           
            employees.add(new PartTimeEmployee(name, JobType.PART_TIME, hourlyRate, hours));
            System.out.println("Part-time employee added successfully!");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numbers for rate and hours.");
        }
    }

    private static void addIntern() {
        try {
            System.out.print("Enter intern name: ");
            String name = scanner.nextLine();
           
            System.out.print("Enter stipend amount: ");
            double stipend = Double.parseDouble(scanner.nextLine());
            if (stipend < 0) {
                System.out.println("Warning: Negative stipend entered. Setting to 0.");
                stipend = 0;
            }
           
            employees.add(new InternEmployee(name, JobType.INTERN, stipend));
            System.out.println("Intern added successfully!");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number for stipend.");
        }
    }

    private static void viewAllEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No employees in the system.");
            return;
        }
       
        System.out.println("\nEmployee Details:");
        for (Employee emp : employees) {
            emp.displayDetails();
        }
    }

    private static void removeEmployee() {
        if (employees.isEmpty()) {
            System.out.println("No employees to remove.");
            return;
        }
       
        System.out.println("\nCurrent Employees:");
        for (int i = 0; i < employees.size(); i++) {
            System.out.printf("%d. %s (%s)%n", i+1,
                    ((AbstractEmployee)employees.get(i)).getName(),
                    ((AbstractEmployee)employees.get(i)).getJobType());
        }
       
        try {
            System.out.print("Enter employee number to remove: ");
            int index = Integer.parseInt(scanner.nextLine()) - 1;
           
            if (index >= 0 && index < employees.size()) {
                String name = ((AbstractEmployee)employees.get(index)).getName();
                employees.remove(index);
                System.out.println(name + " removed successfully.");
            } else {
                System.out.println("Invalid employee number.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid employee number.");
        }
    }
    public static void main(String[] args) {
        boolean running = true;
       
        while (running) {
            System.out.println("\nEmployee Management System");
            System.out.println("1. Add Full-Time Employee");
            System.out.println("2. Add Part-Time Employee");
            System.out.println("3. Add Intern");
            System.out.println("4. View All Employees");
            System.out.println("5. Remove Employee");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
           
            try {
                int choice = Integer.parseInt(scanner.nextLine());
               
                switch (choice) {
                    case 1:
                        addFullTimeEmployee();
                        break;
                    case 2:
                        addPartTimeEmployee();
                        break;
                    case 3:
                        addIntern();
                        break;
                    case 4:
                        viewAllEmployees();
                        break;
                    case 5:
                        removeEmployee();
                        break;
                    case 6:
                        running = false;
                        System.out.println("Exiting system...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    
}