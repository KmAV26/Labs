import java.util.ArrayList;

public class Member {

private String name;
private ArrayList<Book> book1;
	
public Member(String name) {
	this.name = name;
	this.book1 = new ArrayList<>();
}
public void borrowBook(Library library, String title) {
	for(Book book : book1) {	
	if(library.searchBook(title) == true) { 
			book1.remove(book1.indexOf(title));
		System.out.println(title + " has been borrowed");
		}else {
			System.out.println("Sorry " + title + " is currently checked out.");
		}
	}
	}
	public void returnBook(Library library, String title) {
		for(Book book : book1) {	
			if(library.searchBook(title) == false) { 
					book1.add(book);
					System.out.println(title + " has been returned.");
				}else {
					System.out.println(title + " is already in the system.");
				}
			}
			}
	}

