import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Library library = new Library();
		Book book1 = new Book("Test", "Group11", true);
		Book book2 = new Book("Test2", "Group10", true);
		Book book3 = new Book("Test3", "Group09", true);
		
		library.addBook(book1);
		library.addBook(book2);
		library.addBook(book3);

		//library.removeBook("Test");
		library.displayBook();
		
		Member member = new Member("Alice");
		member.borrowBook(library, "Test2");
		member.returnBook(library, "Test2");
	}
		
	}

