import java.util.ArrayList;
public class Library {
	ArrayList<Book> book1 = new ArrayList<>();
public Library() {
	book1 = new ArrayList<>();
	
}

public void addBook(Book book) {
	book1.add(book);
}
public void removeBook(String title) {
	for (Book book : book1) {
		if(book.getTitle().equals(title)) {
			book1.remove(book);
			return;
		}
	}

}

public void displayBook() {
for(Book book : book1) {
	System.out.println(book);
}


}
public boolean searchBook(String title) {
	for(Book book : book1) {
		if(book.getTitle().equals(title) == true) {
			System.out.println("Book is available");
			return true;
		}else {
			System.out.println("Book is not available");
		}
	}
	return false;
}


}