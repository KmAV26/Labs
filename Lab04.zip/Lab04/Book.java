
public class Book {

	private String title;
	private String name;
	boolean isAvailable;
	

	public String getTitle() {
		return title;
	}

	public String getName() {
		return name;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public Book(String title, String name, boolean isAvailable) {
	this.title = title;
	this.name = name;
	this.isAvailable = isAvailable;
	}

	public void borrowBook() {
	if(this.isAvailable = true) {
		isAvailable = !isAvailable;
		System.out.println(this.title + " has been borrowed.");
	}else {
		System.out.println(this.title + " is already being borrowed.");
	}
	}
	
	public void returnBook() {
		if(this.isAvailable = false) {
			isAvailable = !isAvailable;
			System.out.println(this.title + " has been returned.");
		}else {
			System.out.println(this.title + " was not previously borrowed.");
		}
	}


	public String toString() {
	String bookInfo = "Title: " + this.title + " Name: " + this.name + " Availability: " + this.isAvailable;
	return bookInfo;
	}
	}
